/**
 * Clase para probar el funcionamiento del código
 * @author Área de programación UQ
 * @since 2023-08
 * 
 * Licencia GNU/GPL V3.0 (https://raw.githubusercontent.com/grid-uq/poo/main/LICENSE) 
 */
package co.edu.uniquindio.poo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import java.util.logging.Logger;
import org.junit.jupiter.api.Test;

import co.edu.uniquindio.poo.Enums.Color;
import co.edu.uniquindio.poo.Enums.Especie;
import co.edu.uniquindio.poo.Enums.Genero;
import co.edu.uniquindio.poo.Enums.Raza;


/**
 * Unit test for simple App.
 */
public class VeterinariaTest {
    private static final Logger LOG = Logger.getLogger(VeterinariaTest.class.getName());

    /**
     * Rigorous Test :-)
     */
    @Test
    public void datosCompletos(){
        LOG.info("Inicio de test datosCompletos");

        var mascota = new Animal("Bob","100",Especie.PERRO, Raza.BULLDOG, (byte)2, Genero.MACHO, Color.BLANCO, 18.6f);

        assertEquals("Bob", mascota.getNombre());
        assertEquals(Especie.PERRO, mascota.getEspecie());
        assertEquals(Raza.BULLDOG, mascota.getRaza());
        assertEquals((byte)2, mascota.getEdad());
        assertEquals(Genero.MACHO, mascota.getGenero());
        assertEquals(Color.BLANCO, mascota.getColor());
        assertEquals(18.6f, mascota.getPeso());

        LOG.info("fin de test datosCompletos");
    }

    @Test
    public void datosNulos(){
        LOG.info("Inicio de test datos nulos");

        assertThrows(Throwable.class, ()->new Animal(null,null, null, null, (byte)0, null, null, 0f));

        LOG.info("fin del test datos nulos");
      
    }

    @Test
    public void edadNegativo(){
        assertThrows(Throwable.class, ()-> new Animal("Bob", "100", Especie.PERRO, Raza.BULLDOG , (byte)-2, Genero.MACHO, Color.BLANCO, 0f));
    }

    @Test
    public void pesoNegativo(){
        assertThrows(Throwable.class, ()-> new Animal("Bob","100", Especie.PERRO, Raza.BULLDOG, (byte)2, Genero.MACHO, Color.BLANCO, -18.6f));
    }

    @Test
    public void datosVacios(){
        LOG.info("Inicio de test datosVacios");

        assertThrows(Throwable.class, ()-> new Animal(" ","100", Especie.PERRO, Raza.BULLDOG, (byte)0, Genero.MACHO, Color.BLANCO, 0f)); 
    }

    @Test
    public void mascotaRepetida(){
        LOG.info("Inicio de test mascotasRepetidas");

        LOG.info("Fin del test mascotasRepetidas");
    }

}
