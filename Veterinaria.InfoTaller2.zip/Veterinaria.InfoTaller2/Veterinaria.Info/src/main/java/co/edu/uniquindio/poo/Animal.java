package co.edu.uniquindio.poo;

import java.util.List;

import co.edu.uniquindio.poo.Enums.Color;
import co.edu.uniquindio.poo.Enums.Especie;
import co.edu.uniquindio.poo.Enums.Genero;
import co.edu.uniquindio.poo.Enums.Raza;

public class Animal {
    private String nombre;
    private String id;
    private Especie especie;
    private Raza raza;
    private byte edad;
    private Genero genero;
    private Color color;
    private float peso;

    public Animal(String nombre,String id, Especie especie, Raza raza, byte edad, Genero genero, Color color,
            float peso) {

        assert nombre != null && !nombre.isBlank():"debe de tener nombre";
        assert id != null && !nombre.isBlank():" el animal debe de tener id  ";
        assert especie !=null:"es necesario la especie" ;
        assert raza!=null:"es necesario la raza";
        assert genero!=null: "es necesario el genero";
        assert color!=null: "es necesario el color";
        assert edad>=0: "la edad no puede ser negativa";
        assert peso >=0f: "el peso no puede ser nevativo";

        this.nombre = nombre;
        this.especie = especie;
        this.raza = raza;
        this.edad = edad;
        this.genero = genero;
        this.color = color;
        this.peso = peso;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getId(){
        return id;
    }

    public void setId (String id){
        this.id=id;
    }

    public Especie getEspecie() {
        return especie;
    }

    public void setEspecie(Especie especie) {
        this.especie = especie;
    }

    public Raza getRaza() {
        return raza;
    }

    public void setRaza(Raza raza) {
        this.raza = raza;
    }

    public byte getEdad() {
        return edad;
    }

    public void setEdad(byte edad) {
        this.edad = edad;
    }

    public Genero getGenero() {
        return genero;
    }

    public void setGenero(Genero genero) {
        this.genero = genero;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    @Override
    public String toString() {
        return " la Mascota cuenta con los siguientes datos :" + 
                "\n Su Nombre es :" + nombre+ 
                "\n Su Especie:" + especie +
                "\n Su Raza:" + raza +
                "\n Su Edad:" + edad +
                "\n Su Genero:" + genero +
                "\n Su color:" + color +
                "\n Su Peso en kg:" + peso+
                "\n-------------------------||";

        
    }
  @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Animal)) {
            return false;
        }
        Animal otro = (Animal) obj;
        return this.nombre.equals(otro.nombre) && this.id.equals(otro.id);
    }

    // método que valida si un animal existe en una lista de animales
    public boolean validarAnimalExiste(List<Animal> listaAnimales) {
        for (Animal animalito : listaAnimales) {
            if (this.equals(animalito)) {
                return true;
            }
        }
        return false;
    }
}
