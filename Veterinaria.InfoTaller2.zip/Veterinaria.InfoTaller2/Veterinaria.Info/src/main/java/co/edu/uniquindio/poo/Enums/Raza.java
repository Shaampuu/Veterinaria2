package co.edu.uniquindio.poo.Enums;

public enum Raza {
    BULLDOG,
    SALCHICHA,
    GOLDEN,
    PITBULL,
    PASTOR
}
