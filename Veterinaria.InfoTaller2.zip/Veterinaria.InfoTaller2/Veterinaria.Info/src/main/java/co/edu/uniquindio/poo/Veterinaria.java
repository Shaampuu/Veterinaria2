package co.edu.uniquindio.poo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/* 
 * Ejercicio: 
 * En una veterinaria llamada "Amigos Peludos", el Dr. Martínez busca implementar un sistema de gestión de pacientes para simplificar
 *  el registro y seguimiento de los animales atendidos. Para ello, este sistema almacenará la información detallada de cada mascota, 
 * incluyendo nombre, especie, raza, edad, género, color y  peso.
 * 
*@since 03/03/2024
 *@author Jorge Simon Nieto Celemin
 * Licencia GNU/GPL V3.0 (https://raw.githubusercontent.com/grid-uq/poo/main/LICENSE) 
 */

public class Veterinaria {


    private List<Animal>listaAnimales;

    public Veterinaria() {
        this.listaAnimales = new ArrayList<Animal>();
    }
   

    // -----------------------------------------------
    public Collection<Animal> getListaAnimales() {
        return listaAnimales;
    }

    public void setListaAnimales(Collection<Animal> listaAnimales) {
        this.listaAnimales.clear();  
        this.listaAnimales.addAll(listaAnimales);
    }
    // ------------------------------------------------

    public void registrarAnimal(Animal animal) {
        assert !animal.validarAnimalExiste(listaAnimales) : "El animal ya existe";
        listaAnimales.add(animal);
        Collections.sort(listaAnimales, (a1, a2) -> a1.getNombre().compareTo(a2.getNombre())); 
        // Ordenamos la lista por el nombre de los animales
    }

    
    @Override
    public String toString() {
        return "\n *Veterinaria listaAnimales :* " + listaAnimales + "."+"\n";
 
    }
   
}