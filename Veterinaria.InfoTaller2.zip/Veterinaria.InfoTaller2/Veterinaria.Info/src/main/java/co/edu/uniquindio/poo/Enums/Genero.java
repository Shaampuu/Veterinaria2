package co.edu.uniquindio.poo.Enums;

public enum Genero {
    MACHO,
    HEMBRA
}
