package co.edu.uniquindio.poo;

import co.edu.uniquindio.poo.Enums.Color;
import co.edu.uniquindio.poo.Enums.Especie;
import co.edu.uniquindio.poo.Enums.Genero;
import co.edu.uniquindio.poo.Enums.Raza;


/**
 * Hello world!
 *
 */
public class App {
    public static void main(String[] args) {
      
      var primerAnimal = new Animal("Bob","323422" ,Especie.PERRO, Raza.BULLDOG, (byte) 2, Genero.MACHO, Color.BLANCO, 18.6f);
      var tercerAnimal = new Animal("Arra", "786", Especie.PERRO, Raza.GOLDEN, (byte)4, Genero.MACHO, Color.CAFE, 12.0f);
      var segundoAnimal = new Animal("Vela", "323421", Especie.PERRO,Raza.SALCHICHA, (byte)2, Genero.HEMBRA, Color.NARANJA, 15.0f);
     
    
      var veterinaria = new Veterinaria();

      veterinaria.registrarAnimal(primerAnimal);
      veterinaria.registrarAnimal(tercerAnimal);
      veterinaria.registrarAnimal(segundoAnimal);

  
    

      System.out.println("*La lista de animales es:* "+ veterinaria.getListaAnimales());
    }
    
}
