package co.edu.uniquindio.poo.Enums;

public enum Especie {
    PERRO,
    GATO
    
}
