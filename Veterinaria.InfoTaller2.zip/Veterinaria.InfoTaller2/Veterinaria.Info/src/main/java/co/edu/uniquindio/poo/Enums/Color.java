package co.edu.uniquindio.poo.Enums;

public enum Color {
    BLANCO,
    NEGRO,
    CAFE,
    MANCHAS,
    NARANJA
}
